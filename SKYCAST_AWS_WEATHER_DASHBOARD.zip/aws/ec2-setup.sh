#!/usr/bin/env bash
# ==============================================================================
# SKYCAST — AWS EC2 User Data / Host Provisioning Script
# Target OS: Ubuntu 22.04 LTS / 24.04 LTS
# Purpose: Automatically install Python 3.11+, Nginx, Gunicorn, systemd service,
#          and configure IMDSv2 compatible environment behind AWS ALB.
# ==============================================================================

set -euo pipefail

echo "=========================================="
echo " Starting SKYCAST Provisioning on AWS EC2 "
echo "=========================================="

# 1. Update OS packages
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get upgrade -y

# 2. Install dependencies (Python, Git, Nginx, curl, jq)
apt-get install -y python3-pip python3-venv python3-dev nginx git curl jq

# 3. Create dedicated system user for skycast
if ! id -u skycast > /dev/null 2>&1; then
    useradd -m -s /bin/bash skycast
fi

# 4. Clone or deploy application to /var/www/skycast
APP_DIR="/var/www/skycast"
mkdir -p "$APP_DIR"
chown -R skycast:skycast "$APP_DIR"

# Note: In production or CI/CD, clone repo or sync from S3:
# aws s3 sync s3://your-bucket/skycast-release /var/www/skycast/
cd "$APP_DIR"

# 5. Set up virtual environment as skycast user
sudo -u skycast python3 -m venv "$APP_DIR/.venv"
sudo -u skycast "$APP_DIR/.venv/bin/pip" install --upgrade pip
if [ -f "$APP_DIR/requirements.txt" ]; then
    sudo -u skycast "$APP_DIR/.venv/bin/pip" install -r "$APP_DIR/requirements.txt"
fi
sudo -u skycast "$APP_DIR/.venv/bin/pip" install gunicorn

# 6. Install systemd service unit
cat << 'EOF' > /etc/systemd/system/skycast.service
[Unit]
Description=SKYCAST Weather Intelligence Flask Service
After=network.target

[Service]
User=skycast
Group=www-data
WorkingDirectory=/var/www/skycast
Environment="PATH=/var/www/skycast/.venv/bin"
Environment="PORT=5000"
Environment="FLASK_DEBUG=0"
ExecStart=/var/www/skycast/.venv/bin/gunicorn --workers 3 --bind 127.0.0.1:5000 --access-logfile /var/log/skycast/access.log --error-logfile /var/log/skycast/error.log app:app
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

mkdir -p /var/log/skycast
chown -R skycast:www-data /var/log/skycast

# 7. Configure Nginx Reverse Proxy
cat << 'EOF' > /etc/nginx/sites-available/skycast
server {
    listen 80 default_server;
    listen [::]:80 default_server;
    server_name _;

    # Client body limit
    client_max_body_size 10M;

    # Static file direct serving for maximum performance
    location /static/ {
        alias /var/www/skycast/static/;
        expires 7d;
        add_header Cache-Control "public, no-transform";
    }

    # Pass all other traffic to Gunicorn WSGI
    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_connect_timeout 5s;
        proxy_read_timeout 60s;
    }

    # Health check passthrough
    location /api/health {
        proxy_pass http://127.0.0.1:5000/api/health;
        proxy_set_header Host $host;
        access_log off;
    }
}
EOF

ln -sf /etc/nginx/sites-available/skycast /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default

# 8. Test Nginx and reload services
nginx -t
systemctl daemon-reload
systemctl enable skycast
systemctl restart skycast
systemctl restart nginx

echo "=========================================="
echo " SKYCAST EC2 Deployment Setup Complete!   "
echo "=========================================="
